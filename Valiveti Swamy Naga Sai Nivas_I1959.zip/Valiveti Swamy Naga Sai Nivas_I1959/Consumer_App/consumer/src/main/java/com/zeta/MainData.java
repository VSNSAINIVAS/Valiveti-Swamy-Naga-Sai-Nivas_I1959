package com.zeta;
// Importing the required classes
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Make this spring boot application
@SpringBootApplication
public class MainData {
	public static void main(String[] args){
		// Starting the IOC container and running
		SpringApplication.run(MainData.class, args);
	}
}
