package com.zeta.controller;
// Importing required collections
import java.util.Map;
// Importing required spring classes
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.helper.Helper;
// Importing service
import com.zeta.service.DataServiceImpl;
// Making this rest Controller
@RestController
public class DataController {
	// Creating connection between controller and service
	@Autowired
	DataServiceImpl ds;
	// Mapping to the url data to get compete data
	@GetMapping("/data")
	public Map<Object, Object> getData(){
		// Returning the data
		Helper.getLogger(DataController.class).info(ds.getData());
		return ds.getData();
	}
	// Mapping to the url data and get page
	@GetMapping("/data/page")
	public Object getPageData(){
		Helper.getLogger(DataController.class).info(ds.getData().get("page"));
		return ds.getData().get("page");
	}
	// Mapping to the url data and get per page
	@GetMapping("/data/per_page")
	public Object getPerPage(){
		Helper.getLogger(DataController.class).info(ds.getData().get("per_page"));
		return ds.getData().get("per_page");
	}
	// Mapping to the url data and get total
	@GetMapping("/data/total")
	public Object getTotal(){
		Helper.getLogger(DataController.class).info(ds.getData().get("total"));
		return ds.getData().get("total");
	}
	// Mapping to the url data and get total_pages
	@GetMapping("/data/total_pages")
	public Object getTotalPages(){
		Helper.getLogger(DataController.class).info(ds.getData().get("total_pages"));
		return ds.getData().get("total_pages");
	}
	// Mapping to the url data to get the data
	@GetMapping("/data/complete")
	public Object get(){
		Helper.getLogger(DataController.class).info(ds.getData().get("data"));
		return ds.getData().get("data");
	}
}
