package com.zeta.service;
// Importing the required Collections
import java.util.Map;
// Interface for Service
public interface IDataService {
	public Map<Object, Object> getData();
}
