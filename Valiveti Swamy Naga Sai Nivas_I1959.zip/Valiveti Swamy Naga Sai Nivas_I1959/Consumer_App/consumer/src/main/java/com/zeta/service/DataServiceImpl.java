package com.zeta.service;
// Importing required collections
import java.util.Map;
// Importing required spring classes
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
// Importing required user classes
import com.zeta.Main;
import com.zeta.helper.Helper;
// Creating service
@Service
public class DataServiceImpl implements IDataService{
	// Method to obtain the data
	@Override
	public Map<Object, Object> getData() {
		try {
        	// RestTemplate to get the data from the api
            RestTemplate restTemplate = new RestTemplate();
            // Creating headers which set and add the user agent
            HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<?> entity = new HttpEntity<>(headers);
            // Url
            String url = "https://reqres.in/api/users";
            // Getting the response
            ResponseEntity<Object> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    new ParameterizedTypeReference<Object>() {});

            @SuppressWarnings("unchecked")
			Map<Object, Object> res = (Map<Object, Object>) response.getBody();
            Helper.getLogger(Main.class).info("Objects retrieved!");
            return res;
        } catch (HttpClientErrorException e) {
        	Helper.getLogger(Main.class).info("An error occurred!");
        	return null;
        }
	}
	
}
