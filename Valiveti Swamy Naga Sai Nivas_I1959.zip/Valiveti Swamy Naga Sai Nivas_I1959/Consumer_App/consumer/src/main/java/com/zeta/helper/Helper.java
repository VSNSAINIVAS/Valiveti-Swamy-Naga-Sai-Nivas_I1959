package com.zeta.helper;
// Importing required logging packages
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

// Helper class for creating logger
public class Helper {
	public static Logger getLogger(Class <?> c){
		Logger lg = LogManager.getLogger(c);
		// Returning the logger created
		return lg;
	}
}
