package com.zeta.test;

// Importing required classed from packages

import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.zeta.model.Loan;
import static org.junit.Assert.*;
// Importing required data types and collections
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

// Validate class to check if two loans are equal or not
class Validate {
	public boolean check(Loan ln1, Loan ln2) {
		boolean a = ln1.getAadharNo().equals(ln2.getAadharNo());
		boolean b = ln1.getFullName().equals(ln2.getFullName());
		boolean c = ln1.getLastName().equals(ln2.getLastName());
		boolean d = (ln1.getLoanAmount() == ln2.getLoanAmount()) ? true:false;
		boolean e = (ln1.getLoanNo() == ln2.getLoanNo()) ? true:false;
		boolean f = (ln1.getLoanStartDate().toString().equals(ln2.getLoanStartDate().toString()));
		boolean g = (ln1.getTenure() == ln2.getTenure()) ? true : false;
		return a && b && c && d && e && f && g;
	}
}

public class LoanControllerJunitTest {
	// The below test is for getAll method
	@Test
	public void getAll() {
		// Adding the initial table contents to the collection
		List<String> check = new ArrayList<String>();
		check.add("1#603854628529#Valiveti Swamy Naga Sai Nivas#Valiveti#100.0#2024-02-03#3");
		check.add("2#123456788765#Mahesh#Babu#1000.0#2024-02-03#6");
		check.add("3#876543211234#Ram Charan#Cherry#1234.0#2024-02-03#12");
		RestTemplate restTemplate = new RestTemplate();
		// Creating new ResponseEntity with List of Loans
		ResponseEntity<List<Loan>> response = restTemplate.exchange(
				"http://localhost:9000/loans", 
				HttpMethod.GET, 
				null,
				new ParameterizedTypeReference<List<Loan>>() {
				});
		List<Loan> loans = response.getBody();
		// Check for the truth value
		boolean truth = true;
		int idx = 0;
		for (Loan l : loans)
			truth = truth && l.toString().equals(check.get(idx++));
		assertEquals(true, truth);
	}

	// The below test is for getById method
	@Test
	public void getById() {
		String check = "1#603854628529#Valiveti Swamy Naga Sai Nivas#Valiveti#100.0#2024-02-03#3";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Loan> response = restTemplate.exchange(
				"http://localhost:9000/loan/1", 
				HttpMethod.GET, 
				null, 
				Loan.class);
		assertEquals(true, response.getBody().toString().equals(check));
	}

	// The below test is for add method
	@Test
	public void addTest() throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		Loan ln = new Loan();
		java.util.Date dt1 = new java.util.Date();
		Date dt = new Date(dt1.getTime());
		ln.setLoanNo(4);
		ln.setAadharNo("603854628592");
		ln.setFullName("Aditya");
		ln.setLastName("Valiveti");
		ln.setLoanAmount(12209);
		ln.setLoanStartDate(dt);
		ln.setTenure(1);

		// Set up HTTP headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		// Create HTTP entity with headers and request body
		HttpEntity<Loan> requestEntity = new HttpEntity<>(ln, headers);

		// Specify the URI
		String uri = "http://localhost:9000/loan/add";

		// Make the POST request with headers
		Loan res = restTemplate.postForObject(uri, requestEntity, Loan.class);
		Validate v = new Validate();
		assertEquals(true, v.check(res, ln));
	}
	
	// The below test is for update method
	@Test
	public void updateTest() throws Exception {
		RestTemplate restTemplate = new RestTemplate();
        Loan ln = new Loan();
        java.util.Date dt1 = new java.util.Date();
        Date dt = new Date(dt1.getTime());
        ln.setLoanNo(4);
        ln.setAadharNo("603854628592");
        ln.setFullName("Shanmukha Guru Aditya");
        ln.setLastName("Valiveti");
        ln.setLoanAmount(12209);
        ln.setLoanStartDate(dt);
        ln.setTenure(1);
        // Set up HTTP headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        // Create HTTP entity with headers and request body
        HttpEntity<Loan> requestEntity = new HttpEntity<>(ln, headers);
        // Specify the URI
        String uri = "http://localhost:9000/loan/update";
        // Make the PUT request with headers
        ResponseEntity<Loan> response = restTemplate.exchange(
                uri,
                HttpMethod.PUT,
                requestEntity,
                Loan.class
        );
        // Retrieve the updated Loan object from the response
        Loan updatedLoan = response.getBody();
        // Add your assertions or further processing based on the response
        Validate v = new Validate();
        assertEquals(true, v.check(updatedLoan, ln));
	}

	// The below test is for deleteById method
	@Test
	public void deleteById() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.exchange(
				"http://localhost:9000/loan/delete?id=4", 
				HttpMethod.DELETE, 
				null, 
				Loan.class);
		// Checking if the record is deleted from data base
		ResponseEntity<Loan> response = restTemplate.exchange(
				"http://localhost:9000/loan/4", 
				HttpMethod.GET, 
				null, 
				Loan.class);
		boolean truth = false;
		if(response == null || response.getBody() == null) truth = true;
		assertEquals(true, truth);
		
	}

	// The below test is for deleteAll method
//	@Test
//	public void deleteAll() {
//		RestTemplate restTemplate = new RestTemplate();
//		// URL to delete all the loans
//		restTemplate.exchange(
//				"http://localhost:9000/loan/delete/all",
//				HttpMethod.DELETE,
//				null,
//				Loan.class);
//		// To check if the loans are deleted or not
//		ResponseEntity<List<Loan>> response = restTemplate.exchange(
//				"http://localhost:9000/loans", 
//				HttpMethod.GET, 
//				null,
//				new ParameterizedTypeReference<List<Loan>>() {
//				});
//		boolean truth = false;
//		System.out.println(response.getBody().size());
//		if(response == null || response.getBody() == null || response.getBody().size() == 0) truth = true;
//		assertEquals(true, truth);
//	}
}
