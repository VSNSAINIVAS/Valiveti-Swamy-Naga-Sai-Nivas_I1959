package com.zeta.controllers;
// Importing Collections
import java.util.List;
// Importing the Spring required libraries
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
// Importing custom exception class and logger
import com.zeta.exception.LoanNullException;
import com.zeta.helper.Helper;
// Importing the model and service
import com.zeta.model.Loan;
import com.zeta.service.LoanServiceImpl;
import com.zeta.validate.Validation;
// Creating a Rest Controller
@RestController
public class LoanController {
	// Creating connection from controller to service
	@Autowired
	LoanServiceImpl loan;
	// URL mapping
	@GetMapping("/loans")
	public List<Loan> getLoans(){
		// Getting the loans
		List<Loan> res = loan.getLoans();
		try{
			// Validating if we got null
			Validation.checkObjNull(res);
			Helper.getLogger(LoanController.class).info("Loans retrieval successful.");
			return res;
		}
		catch(LoanNullException e){
			Helper.getLogger(LoanController.class).error("Null value received.");
			return null;
		}
		
	}
	// Mapping to URL /loan/id to get the data by id
	@GetMapping("/loan/{id}")
	public Loan getLoan(@PathVariable int id){
		// Getting the loan with id
		Loan res = loan.getLoanById(id);
		try{
			// Validating
			Validation.checkObjNull(res);
			Helper.getLogger(LoanController.class).info("Loan with " + id + " retrieval successful.");
			return res;
		}
		catch(LoanNullException e){
			Helper.getLogger(LoanController.class).error("Null value received");
			return null;
		}
		
	}
	
	// Path to add loan
	@PostMapping(value="/loan/add")
	public Loan addLoan(@RequestBody Loan ln){
		Loan addedLn = loan.addLoan(ln);
		try{
			// Validating
			Validation.checkObjNull(addedLn);
			Helper.getLogger(LoanController.class).info("Loan with " + ln.getLoanNo() + " added successful.");
			return addedLn;
		}
		catch(LoanNullException e){
			Helper.getLogger(LoanController.class).error("Null value received");
			return null;
		}
		
	}
	
	// Path to update loan
	@PutMapping(value="/loan/update")
	public Loan updateLoan(@RequestBody Loan ln){
		Loan updatedLoan = loan.addLoan(ln);
		try{
			// Validating
			Validation.checkObjNull(updatedLoan);
			Helper.getLogger(LoanController.class).info("Loan with " + ln.getLoanNo() + " updation successful.");
			return updatedLoan;
		}
		catch(LoanNullException e){
			Helper.getLogger(LoanController.class).error("Null value received");
			return null;
		}
		
	}
	
	// Path to delete loan
	@DeleteMapping(value="/loan/delete")
	public void deleteLoanById(@RequestParam(name = "id") int val){
		loan.deleteLoan(val);
		Helper.getLogger(LoanController.class).info("Loan with " + val + " deletion successful.");
	}
	
	// Path to delete all loans
	@DeleteMapping(value="/loan/delete/all")
	public void deleteAll(){
		loan.deleteAllLoans();
		Helper.getLogger(LoanController.class).info("Loans deleted successful.");
	}
	
}
