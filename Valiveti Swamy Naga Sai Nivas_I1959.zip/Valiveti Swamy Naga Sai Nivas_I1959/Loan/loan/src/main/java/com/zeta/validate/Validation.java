package com.zeta.validate;

import com.zeta.exception.LoanNullException;;

// Validation method to validate the scenarios and testing if there is any
// error on performing any crud operation
public class Validation{
	public static void checkObjNull(Object ob) throws LoanNullException{
		if(ob == null) throw new LoanNullException("Null pointer exception.");
	}
}
