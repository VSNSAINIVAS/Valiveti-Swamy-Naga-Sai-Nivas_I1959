package com.zeta;
// Importing required classes
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/** 
 * This is for RESTFUL implementation using SPRINGBOOT for performing
 * CRUD operations on LOAN database.
 * */
// Name : Valiveti Swamy Naga Sai Nivas
// ID   : I1959
@SpringBootApplication
@EnableSwagger2
public class Main {
	public static void main(String[] args){
		/* Running the spring boot application and passing the object as 
	 	current class */
		SpringApplication.run(Main.class, args);
	}
}
