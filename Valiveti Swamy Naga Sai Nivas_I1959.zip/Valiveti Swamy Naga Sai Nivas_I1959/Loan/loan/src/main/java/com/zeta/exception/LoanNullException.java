package com.zeta.exception;

// Creating CustomException
public class LoanNullException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Throwing message
	public LoanNullException(String message){
		super(message);
	}
}	
