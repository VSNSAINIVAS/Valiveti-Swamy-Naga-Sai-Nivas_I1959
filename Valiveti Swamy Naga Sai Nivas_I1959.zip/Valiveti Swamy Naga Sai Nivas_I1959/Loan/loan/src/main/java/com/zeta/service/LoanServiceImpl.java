package com.zeta.service;
// Importing required in collections
import java.util.List;
// Importing required spring classes
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
// Importing model & repository
import com.zeta.model.Loan;
import com.zeta.repository.ILoanRepositoryDAO;

// Service layer in layered protocol
@Service
public class LoanServiceImpl implements ILoanService{
	// Creating connection between Service and Repository
	@Autowired
	ILoanRepositoryDAO dao;

	// Getting the list of all loans
	public List<Loan> getLoans() {
		return dao.findAll();
	}

	// Getting the Loan by its id
	public Loan getLoanById(int loanNo) {
		return dao.findOne(loanNo);
	}

	// Adding the loan and returning it 
	public Loan addLoan(Loan ln) {
		return dao.save(ln);
	}

	// Updating the loan and returning it
	public Loan updateLoan(Loan ln) {
		return dao.save(ln);
	}

	// Deleting the loan
	public void deleteLoan(int loanNo) {
		dao.delete(loanNo);
	}

	// Deleting all the loan
	public void deleteAllLoans() {
		dao.deleteAll();
	}
	
}
