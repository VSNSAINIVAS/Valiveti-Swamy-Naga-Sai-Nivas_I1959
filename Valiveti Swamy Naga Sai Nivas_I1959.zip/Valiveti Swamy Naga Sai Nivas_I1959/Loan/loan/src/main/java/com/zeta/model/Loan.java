package com.zeta.model;
// Importing required Data type
import java.sql.Date;
// Importing required jpa classes
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// POJO Loan
@Table
@Entity
public class Loan {
	// Variables of object (or) fields of table
	@Id
	@Column
	private int loanNo;
	@Column
	private String aadharNo;
	@Column
	private String fullName;
	@Column
	private String lastName;
	@Column
	private double loanAmount;
	@Column
	private Date loanStartDate;
	@Column
	private int tenure;
	// Getters and setters methods
	public int getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(int loanNo) {
		this.loanNo = loanNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public Date getLoanStartDate() {
		return loanStartDate;
	}
	public void setLoanStartDate(Date loanStartDate) {
		this.loanStartDate = loanStartDate;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	@Override
	public String toString(){
		return this.loanNo + "#" + this.aadharNo + "#" + this.fullName + "#" +
				this.lastName + "#" + this.loanAmount + "#" +
				this.loanStartDate.toString() + "#" + this.tenure;
	}
	
}
