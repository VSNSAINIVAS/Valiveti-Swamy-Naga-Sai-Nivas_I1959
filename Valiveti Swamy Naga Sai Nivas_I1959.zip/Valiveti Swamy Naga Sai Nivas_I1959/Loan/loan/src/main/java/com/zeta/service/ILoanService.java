package com.zeta.service;

import java.util.List;

import com.zeta.model.Loan;

// Interface which specifies all the methods
public interface ILoanService {
	public List<Loan> getLoans();
	public Loan getLoanById(int loanNo);
	public Loan addLoan(Loan ln);
	public Loan updateLoan(Loan ln);
	public void deleteLoan(int loanNo);
	public void deleteAllLoans();
}
